package com.example.salma.doctolib;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toolbar;

public class ComptePatient extends AppCompatActivity {
    String[] M =  {"jihene","karim"};
    String[] S =  {"orl","oo"};
    String[] A =  {"sfax","ii"};
    String[] T =  {"56","55"};
    String[] D =  {"56","55"};
    String[] H =  {"8:30","7:20"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compte_patient);
        ImageView changeBtn = (ImageView) findViewById(R.id.changeBtn);
        ImageView appBtn = (ImageView) findViewById(R.id.appBtn);
        appBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ListView listView = (ListView) findViewById(R.id.listviewpatient);
                AppListAdapter appAdapter = new AppListAdapter();
                listView.setAdapter(appAdapter);

                /*listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Intent detailIntent = new Intent(getApplicationContext(), ProfileActivity.class);
                        startActivity(detailIntent);
                    }
                });*/

            }
        });

    }
    public class AppListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return M.length;
        }

        @Override
        public Object getItem(int position) {
            return M[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            @SuppressLint({"ViewHolder", "InflateParams"}) View v = getLayoutInflater().inflate(R.layout.item_app, null);
            TextView  nomRdv= (TextView) v.findViewById(R.id.nomMedecinRdvText);
            TextView  spRdv= (TextView) v.findViewById(R.id.specialiteRdvText);
            TextView  addRdv= (TextView) v.findViewById(R.id.addRdvText);
            TextView  telRdv= (TextView) v.findViewById(R.id.telRdvText);
            TextView  dateRdv= (TextView) v.findViewById(R.id.dateRdvText);
            TextView  heureRdv= (TextView) v.findViewById(R.id.heureText);

            nomRdv.setText(M[position]);
            spRdv.setText(S[position]);
            addRdv.setText(A[position]);
            telRdv.setText(T[position]);
            dateRdv.setText(D[position]);
            heureRdv.setText(H[position]);

            return v;
        }
    }
}
