package com.example.salma.doctolib.Utils;

public class Constants {
    private final static String URL_ROOT="http://192.168.1.13/doctogo/v1/";
    public  final static String registerUrlM = URL_ROOT + "RegisterMedecin.php";
    public  final static String loginUrlM = URL_ROOT + "loginMedecin.php";

    public  final static String registerUrlC = URL_ROOT + "RegisterClient.php";
    public  final static String loginUrlC = URL_ROOT + "loginClient.php";
   // public  final static String getMedBySp = URL_ROOT + "getMedBySpecialite.php?specialite=";

}
