package com.example.salma.doctolib;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class listTimeActivity extends AppCompatActivity {
    String[] TIMES = {"8:30", "9:00", "9:30", "10:00", "10:30", "11:00", "11:30", "14:30", "15:00", "15:30",
            "16:00", "16:30", "17:00", "17:30", "18:00", "18:30"};

    String date;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_time);
        ListView listView = (ListView) findViewById(R.id.listviewtime);
        TimeListAdapter timeAdapter = new TimeListAdapter();
        listView.setAdapter(timeAdapter);
        Button confirmBtn = (Button) findViewById(R.id.confirmBtn);
        TextView mydate = (TextView) findViewById(R.id.yourDateText) ;
        date = getIntent().getExtras().getString("date");
        mydate.setText(date);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Toast.makeText(listTimeActivity.this, " votre rendez-vous est le " + date + " vers " + TIMES[position], Toast.LENGTH_SHORT).show();
            }
        });

        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent detailIntent = new Intent(getApplicationContext(), AuthentificationActivity.class);
                startActivity(detailIntent);
                finish();
            }
        });
    }

    public class TimeListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return TIMES.length;
        }

        @Override
        public Object getItem(int position) {
            return TIMES[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            @SuppressLint({"ViewHolder", "InflateParams"}) View v = getLayoutInflater().inflate(R.layout.item_time, null);
            TextView time = (TextView) v.findViewById(R.id.timeText);
            time.setText(TIMES[position]);
            return v;
        }
    }
}
