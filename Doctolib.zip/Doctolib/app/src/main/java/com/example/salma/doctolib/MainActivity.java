package com.example.salma.doctolib;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    String searchSpecial ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button searchButton =(Button) findViewById(R.id.activity_main_search_btn);
        AutoCompleteTextView ss = (AutoCompleteTextView) findViewById(R.id.specialiteSearchViewEdit);
        searchSpecial = ss.getText().toString();
        ImageView img = (ImageView) findViewById(R.id.personImage);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent detailIntent = new Intent(getApplicationContext(), listMedecinActivity.class);
                detailIntent.putExtra("searchSp",searchSpecial);
                startActivity(detailIntent);
            }
        });
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent deIntent = new Intent(getApplicationContext() , AuthentificationActivity.class);
                startActivity(deIntent);
                finish();
            }
        });
    }
}
