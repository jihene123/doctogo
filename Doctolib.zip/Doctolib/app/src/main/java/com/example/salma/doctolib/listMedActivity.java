package com.example.salma.doctolib;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class listMedActivity extends AppCompatActivity {
    String[] NOM = {"j"};
    String[] SP= {"jv"};
    String[] ADRESSE={"fkn"};
    Integer[] PRIX ={55};
    String[] PROCHE={"vcv"} ;
    String specialite="l";
    ListView listView ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_medecin);
        ListView listView = (ListView) findViewById(R.id.listviewmedecin);
        MedecinListAdapter medecinAdapter = new MedecinListAdapter();
        listView.setAdapter(medecinAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent detailIntent = new Intent(getApplicationContext(), ProfileActivity.class);
                startActivity(detailIntent);
            }
        });
    }
    public class MedecinListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return NOM.length;
        }

        @Override
        public Object getItem(int position) {
            return NOM[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            @SuppressLint({"ViewHolder", "InflateParams"}) View v = getLayoutInflater().inflate(R.layout.item_medecin, null);
            TextView nomA = (TextView) v.findViewById(R.id.nomMedecinEdit);
            TextView specialitegA = (TextView) v.findViewById(R.id.specialiteEdit);
            TextView prixA = (TextView) v.findViewById(R.id.prixEdit);
            TextView adresseA = (TextView) v.findViewById(R.id.addEdit);
            TextView prochdispoA = (TextView) v.findViewById(R.id.prochDispoEdit);
            nomA.setText(NOM[position]);
            specialitegA.setText(SP[position]);
            String spA = specialitegA.getText().toString().trim();
            adresseA.setText(ADRESSE[position]);
            prixA.setText(PRIX[position].toString());
            prochdispoA.setText(PROCHE[position]);
            return v;
        }
    }
}
